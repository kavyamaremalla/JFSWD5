package com.jpa.demo.springjpademo.service;

import com.jpa.demo.springjpademo.entity.User;

import java.util.List;

public interface UserService {

    User createUser(User user);

    List<User> getAllUsers();

    User getUserById(Long userId);

    User updateUser(User user);

    void deleteUser(Long userId);
}
