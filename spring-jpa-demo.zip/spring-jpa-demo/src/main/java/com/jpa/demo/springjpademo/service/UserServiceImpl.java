package com.jpa.demo.springjpademo.service;

import com.jpa.demo.springjpademo.entity.User;
import com.jpa.demo.springjpademo.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService{

    private UserRepository userRepository;

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long userId) {
        User userById = userRepository.findById(userId).get();
        return userById;
    }

    @Override
    public User updateUser(User user) {

        User updatedUser = userRepository.findById(user.getId()).get();
        updatedUser.setFirstName(user.getFirstName());
        updatedUser.setLastName(user.getLastName());
        updatedUser.setEmail(user.getEmail());

        return userRepository.save(updatedUser);
    }

    @Override
    public void deleteUser(Long userId) {
     userRepository.deleteById(userId);
    }
}
