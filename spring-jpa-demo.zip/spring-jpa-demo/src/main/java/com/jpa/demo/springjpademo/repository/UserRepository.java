package com.jpa.demo.springjpademo.repository;

import com.jpa.demo.springjpademo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long>{

}
