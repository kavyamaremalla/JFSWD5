
const apiRequest = async (API_URL, options = null) => {
  let response = null;
  try {
    response = await fetch(API_URL, options);
    console.log(response);
    if(!response.ok) throw new Error("Data Not Found")
  } catch (error) {
    console.log(error.message);
}
  return response;
};

export default apiRequest;
