import React from "react";

const Header = ({ title }) => {
  return (
    <header>
      <h1>{title} </h1>
    </header>
  );
};

Header.defaultProps = {
  title : "Demo To-Do List"
}

export default Header;
