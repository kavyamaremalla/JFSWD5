package com.spring.training;

public class Traveler {
      private  Vehicle vehicle;

    public Traveler(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    Boolean roadTrip = true;

       public void startJourney(){
           if(roadTrip){
               vehicle = new Car();
           }else{
               vehicle = new Bike();
           }
        }

}
