package com.spring.training;

public class Car implements Vehicle{

    @Override
    public void move() {
        System.out.println("Using Car");
    }
}
