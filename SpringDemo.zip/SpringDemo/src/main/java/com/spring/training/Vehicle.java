package com.spring.training;

public interface Vehicle {

    public void move();
}
