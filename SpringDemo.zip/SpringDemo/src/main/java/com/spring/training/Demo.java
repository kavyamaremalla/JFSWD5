package com.spring.training;

public class Demo {

    public static void main(String[] args) {

       Traveler traveler = new Traveler(new Bike());

       traveler.startJourney();
    }
}