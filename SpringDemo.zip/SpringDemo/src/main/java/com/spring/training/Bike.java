package com.spring.training;

public class Bike implements Vehicle{
    @Override
    public void move() {
        System.out.println("Using Bike");
    }
}
