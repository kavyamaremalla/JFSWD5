package com.example.todomanagement.util;

public class ExtractToken {
    public static void main(String[] args) {
        String header = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlzcyI6InJhbWFfZmluYW5jZS5jb20iLCJpYXQiOjE3MTI1NTg1MjgsImV4cCI6MTcxMjU1ODgyOH0.vfetptqyejCiHNJp3ZJ_5RPcX3zgDFPqcCcMM5UCI48";

        String[] value = header.split(" ");
        System.out.println("0th Index " + value[0]);
        System.out.println("1st Index " + value[1]);
    }
}
