import "./App.css";
import Content from "./Content";
import Footer from "./Footer";
import Header from "./Header";
import React, { useState } from "react";

function App() {
  const [items, setItems] = useState([
    { id: 1, checked: true, description: "Java Task" },
    { id: 2, checked: false, description: "UI Task" },
    { id: 3, checked: true, description: "Git Task" },
    { id: 4, checked: false, description: "DB Task" },
    { id: 5, checked: true, description: "Spring Task" },
  ]);

  const handleCheck = (id) => {
    const listItems = items.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("to-do_List", JSON.stringify(listItems));
    console.log(localStorage.getItem("to-do_List"));
  };

  const deleteTask = (id) => {
    const listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    console.log(listItems);
  };

  return (
    <div className="App">
      <Header title="To-Do List" />
      <Content
        items={items}
        handleCheck={handleCheck}
        deleteTask={deleteTask}
      />
      <Footer length = {items.length}/>
    </div>
  );
}

export default App;
