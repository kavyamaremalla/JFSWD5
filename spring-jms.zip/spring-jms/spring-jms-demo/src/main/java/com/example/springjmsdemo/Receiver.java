package com.example.springjmsdemo;

import com.example.springjmsdemo.dto.Email;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Receiver {

    @JmsListener(destination = "mailbox", containerFactory = "myFactory")
    public void receiveMessage(Email email) {
        System.out.println("Received <" + email + ">");
    }

    @JmsListener(destination = "mailboxTopic", containerFactory = "myFactory")
    public void receiveMessage1(Email email) {
        System.out.println("Received <" + email + ">");
    }

    @JmsListener(destination = "mailboxTopic", containerFactory = "myFactory")
    public void receiveMessage2(Email email) {
        System.out.println("Received <" + email + ">");
    }
}
