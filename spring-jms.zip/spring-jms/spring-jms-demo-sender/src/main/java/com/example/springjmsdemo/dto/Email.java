package com.example.springjmsdemo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
public class Email {

    private String to;

    private String body;
}
