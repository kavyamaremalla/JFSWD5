package com.example.springjmsdemo;

import com.example.springjmsdemo.dto.Email;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.core.JmsTemplate;

@SpringBootApplication
public class SpringJmsDemoSenderApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(SpringJmsDemoSenderApplication.class, args);

		JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);

		System.out.println("Sending a message");
		jmsTemplate.convertAndSend("mailbox", new Email("info@gmail.com", "Hello, Welcome"));
	}


}
