package com.example.accessingdatamongodb.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "products")
public class Product {

    @Id
    private String id;

    private String product_name;

    private int product_price;

    private String product_material;

    private String product_color;

    private List<String> arrayofProducts;
    
    private int quantity;
}
