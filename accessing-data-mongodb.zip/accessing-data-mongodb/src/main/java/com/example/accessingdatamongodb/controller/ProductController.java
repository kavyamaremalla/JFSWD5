package com.example.accessingdatamongodb.controller;

import com.example.accessingdatamongodb.dto.Product;
import com.example.accessingdatamongodb.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductRepository repository; //call repo from a service layer

    /*
    return type should be a response Entity for all the end-points not a static message
     */
    @PostMapping("/addProduct")
    public String saveProduct(@RequestBody Product product){
        repository.save(product);
        return "Product Added successfully";
    }

    @PostMapping("/addProductList")
    public String saveAllProducts(@RequestBody List<Product> productList){
        repository.saveAll(productList);
        return "product list save Successfully";
    }

    @GetMapping("/findAllProducts")
    public List<Product> getProductList(){
        return repository.findAll();
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable String id){
        repository.deleteById(id);
        return  "Deleted Successfully";
    }

}
