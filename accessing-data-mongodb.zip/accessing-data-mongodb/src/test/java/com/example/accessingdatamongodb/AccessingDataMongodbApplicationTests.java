package com.example.accessingdatamongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
