package com.training.advanced.java;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;

public class DateTime {

    public static void main(String[] args) {
       DateTime currentDateTime = new DateTime();
       currentDateTime.testPeriod();
    }

    public  void testLocalDateTime(){
        LocalDateTime currentDateTime = LocalDateTime.now();
        System.out.println("Current Date Time : " + currentDateTime);

        LocalDate localDate = currentDateTime.toLocalDate();
        System.out.println("Local Date : " + localDate);

        Month currentMonth = currentDateTime.getMonth();
        int day = currentDateTime.getDayOfMonth();
        int seconds = currentDateTime.getSecond();

        System.out.println("Month is " + currentMonth);
        System.out.println("Day is " + day);
        System.out.println("Seconds are " + seconds);

        LocalDateTime dateTime = currentDateTime.withDayOfMonth(10).withYear(2023);
        System.out.println("Other Date Time : " + dateTime);

        LocalDate localDate1 = LocalDate.of(2022,12,30);
        System.out.println(localDate1 + " Particular Date");

        LocalTime localTime = LocalTime.parse("13:05:45");
        System.out.println(localTime + " Time is");
    }

    public void zonedDateTime(){

        ZonedDateTime zonedDateTime = ZonedDateTime.parse("2024-02-05T11:32:58.076832500+05:30[Asia/Calcutta]");
        System.out.println( "Current Zoned Date and Time : "+ zonedDateTime );

        ZoneId id = ZoneId.of("Africa/Harare");
        System.out.println("Zone Id is :" + id);

        ZoneId currentZone = ZoneId.systemDefault();
        System.out.println(currentZone); //private desktops -> it  runs of america

        Instant nowUTC = Instant.now();
        ZoneId asiaShanghai = ZoneId.of("Asia/Shanghai");

        ZonedDateTime nowShanghai = ZonedDateTime.ofInstant(nowUTC,asiaShanghai);
        System.out.println(nowShanghai);
    }

    public void testChromoUnits(){
        LocalDate today = LocalDate.now();

        LocalDate nextWeek = today.plus(5, ChronoUnit.YEARS);
        System.out.println(nextWeek);
    }

    public void testPeriod(){

        LocalDate today =LocalDate.now(); // including today
        LocalDate dob =  LocalDate.parse("1990-05-15"); // excluding day

        System.out.print(Period.between(dob,today).getYears() + " years, ");
        System.out.print(Period.between(dob,today).getMonths() + " months, ");
        System.out.print(" and "+ Period.between(dob,today).getDays() + " days.");

        LocalDateTime start = LocalDateTime.parse("2024-02-05T15:10:09.207771100");
        LocalDateTime end = LocalDateTime.parse("2024-02-05T14:10:09.207771100");

        //start>end -> isPositive,
        //start<end -> isNegative,
        //start=end -> isZero
//        System.out.println( Duration.between(start,end).isNegative());
    }
}


