package com.training.advanced.java;

public class TimeComplexity {

    public static void main(String[] args) {

        int i, n = 8;

        for ( i = 1; i <= n; i = i*2) {
            System.out.println("Result is : " + add(1, 2));

        }// O(log2n)
    }

    public static int add(int a, int b){
        int result = a +b;
       return result; // one single addition operation T(n) = O(2), S(1)
    }

}
