package com.training.advanced.java;

public class Matrix {

    public static void main(String[] args) {

        int[] arr = new int[10]; // --> 1D array

        int[][] arr1 = new int[3][4]; //--> 2D Array.

        for (int i = 0; i < arr1.length; i++) { // each line, over rows.
            for (int j = 0; j < arr1[0].length ; j++) {
                arr1[i][j] = 100;
                System.out.print(arr1[i][j] + " ");
            }
            System.out.println("\n");
        }
    }// i * n2 + j*n + c --> O(n*m) --> O(n2), S(nm + 1) O(nm)


}
