package com.training.advanced.java;

import java.util.concurrent.Callable;

public class SumCallable implements Callable {

    int input;

    public SumCallable(int input) {
        this.input = input;
    }

    @Override
    public Integer call() throws Exception {
        Thread.sleep(3000);
        int sum = 0;
        for (int i = 1; i <= input; i++) {
            sum = sum + i;

        }
        return sum;
    }
}
