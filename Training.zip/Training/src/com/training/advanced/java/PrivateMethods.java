package com.training.advanced.java;

public class PrivateMethods implements I{
    public static void main(String[] args) {

    }
    public void add() {

    }

}

interface I{
    void add(); // abstract method
   private static void sub(){
       method2(); // calling static method from static method
   };

     default void multiply(){
         method1(); // private non -static method in default method.
         method2(); // private static method inside a non-static method
     };

    private void method1(){
        System.out.println("Inside Private Method");
    } // Java 9

    private static void method2( ){
        System.out.println("Inside private static");
    } // Java 9

}
