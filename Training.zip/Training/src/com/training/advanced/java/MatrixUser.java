package com.training.advanced.java;

import java.util.Scanner;

public class MatrixUser {

    public static void main(String[] args) {
        readMatrixFromUser();
    }

    public static void readMatrixFromUser() {
        int m, n;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter number of rows in matrix: ");
        m = scanner.nextInt();

        System.out.println("Enter number of columns: ");
        n = scanner.nextInt();

        int matrix[][] = new int[m][n];

        System.out.println("Enter elements in the matrix: ");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        scanner.close();

    }
}
