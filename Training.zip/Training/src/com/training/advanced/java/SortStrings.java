package com.training.advanced.java;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class SortStrings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] inputArray = new String[sc.nextInt()];

        for (int i = 0; i < inputArray.length; i++) {
            inputArray[i] = sc.next();
        }

//        List<String> list = Arrays.stream()
        for (String s : inputArray) {
            System.out.print(s + " ");
        }


    }
}
