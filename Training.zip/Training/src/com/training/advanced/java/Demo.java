package com.training.advanced.java;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

public class Demo implements Runnable{

    Display display;
    String name;

    public Demo(Display display, String name) {
        this.display = display;
        this.name = name;
    }

    public  void run(){
        display.print(name);
    }

    public static void main(String[] args) {

       String firstName = "john";
        String lastName = "Peter";

        //build a database query in java and then we will execute it through db.

        StringBuilder Str = new StringBuilder(); // not support multi threading
        Str.append(firstName);
        Str.append(" ");
        Str.append(lastName); // select few elements


        StringBuffer StrB = new StringBuffer(); //multi threading, thread safe
        StrB.append(firstName);
        StrB.append(" ");
        StrB.append(lastName);

        System.out.println(StrB);

    }
}
