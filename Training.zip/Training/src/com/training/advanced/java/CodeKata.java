package com.training.advanced.java;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;


public class CodeKata {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Scanner ids = new Scanner(System.in);

        int[] arr = new int[input.nextInt()];

        List<Integer> idsList = new ArrayList<>();

        for (int i = 0; i < arr.length; i++) {
            idsList.add(ids.nextInt());
        }
        Map<Integer, Integer> countDuplicate = new HashMap<>(); // counts duplicate :  ids is key, count is value

        int count = 0;
        for (Integer element : idsList) { // all the ids of prisoners

            if (countDuplicate.containsKey(element)) { // duplicate key -> ids
                count = countDuplicate.get(element); //1 for element 6 and second time
                countDuplicate.put(element, count + 1); // 1+1 = 2

            } else {
                countDuplicate.put(element, 1);
            }
        }

        Map<Integer, Integer> resultMap = new HashMap<>();

        for (Map.Entry<Integer, Integer> entry : countDuplicate.entrySet()) {
            if (entry.getValue() > 1) {
                resultMap.put(entry.getKey(), entry.getValue());
            }
        }

        if (resultMap.isEmpty()) {
            System.out.println(-1);
        } else {
            for (Map.Entry<Integer, Integer> entry : resultMap.entrySet()) {
                System.out.print(entry.getKey());
            }
        }

    }
}