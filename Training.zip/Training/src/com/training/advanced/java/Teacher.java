package com.training.advanced.java;

public sealed class Teacher permits StudentDetails, StudentJohn {

    
}
