package com.training.advanced.java;


import java.util.ArrayList;

public class Test {
    //multi threading
    public static void main(String[] args) throws InterruptedException {
        CustomThread.ct = Thread.currentThread();

        CustomThread customThread = new CustomThread();
        Thread thread = new Thread(customThread); // creating another thread and I'm executing CustomThread.
        thread.start(); // initializing thread
        thread.interrupt();
        thread.join(); // Main thread will wait for the Custom thread to execute

        for (int i = 0; i < 5; i++) {
            Thread.sleep(500);
            System.out.println("From Main Thread");
        }
    }
}
class CustomThread implements Runnable {

    static  Thread ct;

    public void run() {
        for (int i = 0; i < 5; i++) {
            try {
                ct.join(); // wait current thread
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("From Custom Thread");
        }
    }
}




