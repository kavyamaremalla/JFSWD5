package com.training.advanced.java;

public class Task {
    public static void main(String[] args) throws InvalidAgeException{
       int age =18;
        if(age<=18){
            throw  new InvalidAgeException("Can't vote!");
        }else{
            System.out.println("Eligible to vote");
        }
    }
}
