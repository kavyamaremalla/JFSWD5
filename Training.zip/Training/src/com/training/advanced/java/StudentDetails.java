package com.training.advanced.java;

public non-sealed class StudentDetails extends Teacher {

}

final class StudentDetails1 extends StudentJohn{

}

sealed class StudentJohn extends Teacher{

}




