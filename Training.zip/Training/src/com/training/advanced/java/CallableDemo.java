package com.training.advanced.java;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class CallableDemo {

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException {

        ExecutorService executorService = Executors.newFixedThreadPool(10);

        List<Future<Integer>> futureList = new ArrayList<>();

        for (int i = 0; i<100; i++){
            Future<Integer> integerFuture = executorService.submit(new SumCallable(10));
            futureList.add(integerFuture);
        }

        for(Future f :futureList){
            System.out.println(f.get(4, TimeUnit.SECONDS)); //waiting for Sumcallable thread
        }
    }


}
