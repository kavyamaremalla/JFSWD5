package com.training.advanced.java;

import java.util.concurrent.*;

public class AsyncExample {

    public static void delay(int seconds) throws InterruptedException {
        TimeUnit.SECONDS.sleep(seconds);
    }
    public static void main(String[] args) {

        ExecutorService executorService =  Executors.newCachedThreadPool();

        Runnable runnable = () -> {
            try {
                delay(2);
                System.out.println("Inside Runnable method " + Thread.currentThread().getName());
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        };

        CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(runnable,executorService);

        System.out.println("Inside main thread " +  Thread.currentThread().getName());
        completableFuture.join();

    }
}
