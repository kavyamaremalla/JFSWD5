package com.training.advanced.java;

public class Display {
    public static synchronized void print(String name){
        for (int i = 0; i < 5; i++){
            System.out.print("Hello ");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(name);
        }
    }
}
