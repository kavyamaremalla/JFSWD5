package com.training.advanced.java;

import java.util.Scanner;

public class AgeCalculation {

    public static void main(String[] args) {

        try {
            validateAge(16);
        } catch (InvalidAgeException e) {
            throw new RuntimeException(e);
        }
    }

   public static void validateAge(int age) throws InvalidAgeException {
        Scanner scanner = new Scanner(System.in);
        if (age < 18) {
            throw new InvalidAgeException("Not Eligible to Vote");
        } else {
            System.out.println("You can vote");
        }
    }
}
