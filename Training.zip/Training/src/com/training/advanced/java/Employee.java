package com.training.advanced.java;

public record Employee(int id , String name) {

    //by default a toString, override hashcode and equals, getter
    //lombok
}
