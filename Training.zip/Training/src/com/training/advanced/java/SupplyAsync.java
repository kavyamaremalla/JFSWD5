package com.training.advanced.java;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

public class SupplyAsync {

    public static void delay(int seconds) throws InterruptedException {
        TimeUnit.SECONDS.sleep(seconds);
    }

    public static void main(String[] args) {

        Supplier<Integer> supplier = () -> {
            try {
                delay(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("Inside Supplier " + Thread.currentThread().getName());
            return 2;
        };

        CompletableFuture<Integer> completableFuture = CompletableFuture.supplyAsync(supplier);
        System.out.println("Main");

        Integer value = completableFuture.join();
        System.out.println(value);
    }

}
