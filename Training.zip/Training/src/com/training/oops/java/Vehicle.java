package com.training.oops.java;

public class Vehicle {

    String globalVariable = "empty";

    public void display(){
        System.out.print("Hello inside parent class");
    }
    // within same package or using a child class
}
