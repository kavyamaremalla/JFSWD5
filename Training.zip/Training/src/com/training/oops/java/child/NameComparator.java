package com.training.oops.java.child;

import java.util.Comparator;

public class NameComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getName().compareTo(o2.getName());
    }

    static class AgeComparator implements Comparator<Student>{

        @Override
        public int compare(Student o1, Student o2) {
            return o1.getAge().compareTo(o2.getAge());
        }
    }

    static class DeptComparator implements Comparator<Student>{

        @Override
        public int compare(Student o1, Student o2) {
            return o1.getDept().compareTo(o2.getDept());
        }
    }
}
