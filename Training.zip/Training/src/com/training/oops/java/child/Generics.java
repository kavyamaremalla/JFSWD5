package com.training.oops.java.child;

public class Generics<T extends Number>{
    public T obj;

    public T getObj() {
        return obj;
    }

    public Boolean add(T obj, T obj1){
        return obj.equals(obj1);
    }
}
