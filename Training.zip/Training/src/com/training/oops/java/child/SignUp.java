package com.training.oops.java.child;


public class SignUp {

    public static void main(String[] args) {

        String userName = "";

       Person person = new Person();

        person.setUserName("John");
//        person.setPassword("1224");

        System.out.println(person.getUserName());
//        System.out.println(person.getPassword());



    }


}
