package com.training.oops.java.child;

public class EconomyTataCar extends TataCar{

//    @Override
    public void breaks() {
        System.out.println("");
    }
}
