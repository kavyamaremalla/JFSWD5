package com.training.oops.java.child;


public  class JavaDemo {

    public  static void add(int a, int b){
        System.out.println("Parent method");
    }
}
