package com.training.oops.java.child;

public abstract class  TataCar  {

}
