package com.training.oops.java.child;

public class GrandChild1 extends Child1{

    void print(){
        System.out.println("Inside grandchild1");
    }

}
