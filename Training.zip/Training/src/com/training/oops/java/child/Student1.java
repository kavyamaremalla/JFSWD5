package com.training.oops.java.child;

public class Student1 implements Human{
    @Override
    public void display() {
        System.out.println("Inside student Class");
    }

}
