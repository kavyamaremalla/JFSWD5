package com.training.oops.java.child;



public class Test  {


    public static void main(String[] args) {

    }

}
