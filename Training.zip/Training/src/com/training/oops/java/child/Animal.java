package com.training.oops.java.child;

public class Animal {
    private static void fly(String a){

        System.out.println(a);
    }

    private static void fly(String o, String l){
        System.out.println(o.concat(l));
    }


    public static void main(String[] args) {
        fly("first");
        fly("acrossOceans", "empty");
    }
}
