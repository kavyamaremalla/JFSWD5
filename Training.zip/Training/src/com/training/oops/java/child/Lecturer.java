package com.training.oops.java.child;

public class Lecturer implements Human{
    @Override
    public void display() {
        System.out.println("Inside Lecturer Class");

    }
}
