package com.training.oops.java.child;

public class Car {

    public static void main(String[] args) {
        PremiumTataCar premiumTataCar = new PremiumTataCar();
        premiumTataCar.breaks();

        EconomyTataCar economyTataCar = new EconomyTataCar();
        economyTataCar.breaks();
    }
}
