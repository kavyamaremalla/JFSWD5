package com.training.oops.java.child;

public class Person { //class

  private String userName; //fields

    private String password; //field

    //getter
    public String getUserName() {
        return userName;
    }
    //setter
    public void setUserName(String userName){
    this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
