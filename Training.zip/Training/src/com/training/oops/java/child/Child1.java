package com.training.oops.java.child;

public class Child1 extends Parent{
    void print(){ // grandchild overridden
        System.out.println("Inside child1");
    }

}
