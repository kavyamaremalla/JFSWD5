package com.training.oops.java.child;

public class Parent { //child and grandchild
    void print(){
        System.out.println("Inside Parent Class");
    }
}
