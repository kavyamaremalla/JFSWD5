package com.training.oops.java.child;

public class Test1 {
    static int rollNum = 100;
    String stuName = "test";
    static String college = "XYZ"; //variables


    public static void main(String[] args) {

        college = "ABC";
        System.out.println(college);

    }
}
