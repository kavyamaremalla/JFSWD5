package com.training.oops.java.child;

public class PremiumTataCar extends TataCar{

//    @Override
    public void breaks() {
        System.out.println("Premium quality brakes");
    }

}
