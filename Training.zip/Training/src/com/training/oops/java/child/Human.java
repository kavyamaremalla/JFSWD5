package com.training.oops.java.child;

public interface Human {
    void display();

}


