package com.training.constructors;

public class Test {
    public static void main(String[] args) {

        Child peter = new Child("1234");
//        System.out.println(peter);

        Child potter = new Child("1234");
        System.out.println(potter);

        System.out.println(peter.hashCode());
        System.out.println(potter.hashCode());

//       System.out.println(peter.equals(potter));






    }
}
