package com.training.constructors;

public class Child1 extends Parent {
    public Child1(){
        System.out.println("inside child 2");
    }
}
