package com.training.constructors;

public class Child extends Parent{

    String password; //hash
    public Child(){
        super();
        System.out.println("From Child Class");
    }

    public Child( String password){
//        super(userName);
        this.password = password;

    }

    public int hashCode() {
        return 31*password.length()+56;
    }

    @Override
    public boolean equals(Object obj) { //
       Child c = (Child) obj; // type casting Object to Child class
     return  this.password.equals(c.password);
    } // try comparing username

    public String toString(){
        return "Password : " + this.password;
    }
}
