package com.training.constructors;

public class Parent {

    String userName;

    public Parent(){
        System.out.println("From Parent");
    }


    public Parent(String userName){
        this.userName = userName;
    }
}
