package com.training.initial;


public class PatternMatching {

    public static void main(String[] args)  {


    }


}
