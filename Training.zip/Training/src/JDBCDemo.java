import java.sql.*;

public class JDBCDemo {

    public static void main(String[] args)  {

        String query = "select * from persons";
        try (Connection connection  = DriverManager.getConnection("jdbc:mysql://localhost/personsdb?user=root&password=Mypwd@123");
              PreparedStatement preparedStatement = connection.prepareStatement(query);

              ResultSet resultSet = preparedStatement.executeQuery()){


            while(resultSet.next()){
                System.out.println(resultSet.getInt(1) + " " +
                        resultSet.getString(2)  +  " " + resultSet.getString(3)
                        +  " " + resultSet.getBoolean(4)
                );
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }



    }
}
