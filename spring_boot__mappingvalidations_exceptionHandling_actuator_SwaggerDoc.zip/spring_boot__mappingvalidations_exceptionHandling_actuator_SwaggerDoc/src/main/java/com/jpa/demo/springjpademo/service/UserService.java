package com.jpa.demo.springjpademo.service;

import com.jpa.demo.springjpademo.dto.UserDto;
import com.jpa.demo.springjpademo.entity.User;

import java.util.List;

public interface UserService {

    UserDto createUser(UserDto userDto);

    List<UserDto> getAllUsers();

    UserDto getUserById(Long userId);

    UserDto updateUser(UserDto userDto);

    void deleteUser(Long userId);
}
