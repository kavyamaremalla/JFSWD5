package com.jpa.demo.springjpademo;

import com.jpa.demo.springjpademo.dto.UserDto;
import com.jpa.demo.springjpademo.entity.User;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@OpenAPIDefinition(
		info = @Info(
				title = "User Management",
				description = "Basic CRUD Operations for a User",
				contact = @Contact(
						name = "John Doe",
						email = "johnd@gmail.com",
						url = "https://wwww.google.com"
				),
				license = @License(name = "Backed up by : Apache 2.0")

		), externalDocs = @ExternalDocumentation(
				description = "CRUD Operations"
)
)
public class SpringJpaDemoApplication {

	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaDemoApplication.class, args);
	}

}
