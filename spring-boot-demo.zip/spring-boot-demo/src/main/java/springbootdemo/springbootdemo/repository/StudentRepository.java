package springbootdemo.springbootdemo.repository;



public class StudentRepository {
}
