package springbootdemo.springbootdemo;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
@OpenAPIDefinition(servers = {@Server(url= "https:studentManagement1.com"),
		@Server(url= "https:studentManagement2.com") }, info = @Info(title = "Student Methods", version = "v1",
			description = "CRUD Operations in StudentManagement", license = @License(name = "Belongs to @School",
			url = "www.facebook.com" )))
public class SpringBootDemoApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringBootDemoApplication.class, args);
//		String [] beans = context.getBeanDefinitionNames();
//		for (String bean: beans ) {
//			System.out.println(bean);
//		}
	}

}
