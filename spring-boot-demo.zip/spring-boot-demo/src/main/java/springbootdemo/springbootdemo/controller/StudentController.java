package springbootdemo.springbootdemo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springbootdemo.springbootdemo.bean.Student;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("students")
public class StudentController {

    static List<Student> studentList = new ArrayList<>();

    static {
        Student student1 = new Student(1, "John", "Doe");
        Student student2 = new Student(2, "Harry", "Potter");
        studentList.add(student1); //0th element
        studentList.add(student2); //1st element
    }

    @GetMapping("/getStudent")
    public ResponseEntity<Object> getStudent(){
        Student student = new Student(3, "John", "Doe");
        return ResponseEntity.ok().body(student);

    }

    @GetMapping("getStudents")
    public ResponseEntity<List<Student>> getStudents(){
        //select * from students
        return ResponseEntity.ok().body(studentList);

    }

    @GetMapping("getStudents/{id}")
    public ResponseEntity<Student> getStudentByID(@PathVariable("id") Integer studentId){
        //select * from students where id =?
        Student student = studentList.get(studentId-1);
        return ResponseEntity.ok().body(student);
    }


    @PostMapping("create")
    public ResponseEntity<List<Student>> createStudent(@RequestBody Student student){
       // {"id":3,"firstName":"Peter","lastName":"Parker"}
       //insert into students(firstName,lastName) values()

        student.setId(studentList.size()+1);
        studentList.add(student);
        return new ResponseEntity<>(studentList, HttpStatus.CREATED);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student
    , @PathVariable("id") Integer studentId){
      //update student set() values () where id =1

        studentList.set(studentId-1, student);

        return ResponseEntity.ok(student);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId){
        //delete * from students where id = 1

        studentList.remove(studentId-1);


        return new ResponseEntity<>
                ("Student  deleted successfully",
                        HttpStatus.NO_CONTENT);
    }


    @Deprecated
    @GetMapping("query")
    public ResponseEntity<Object> getStudentByQuery(@RequestParam int id, @RequestParam String firstName){
        //select * from student where id = 1 or firstName = "John"
        Student student = new Student(id, firstName, "Doe"); //pass params here
        return ResponseEntity.ok().body(student);

    }

}
