package springbootdemo.springbootdemo.service;

public interface StudentInterface {
}
