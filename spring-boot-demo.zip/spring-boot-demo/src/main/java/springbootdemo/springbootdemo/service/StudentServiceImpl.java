package springbootdemo.springbootdemo.service;



public class StudentServiceImpl {

    String getStudent(){
        //validation

        //repository
        return null;
    }
}
