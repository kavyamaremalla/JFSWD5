package springbootdemo.springbootdemo.bean;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {

//    @NonNull
    private Integer id;

    @NonNull
    private String firstName;

    private String LastName;

}
