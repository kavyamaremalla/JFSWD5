import React, { useContext } from "react";
import { FaMobileAlt, FaLaptop, FaTabletAlt } from "react-icons/fa";
import DataContext from "./context/DataContext"

const Header = ({ title, width }) => {
  // const context = useContext(DataContext);
  // const width = context.width;

  // const { width } = useContext(DataContext);

  return (
    <header className="Header">
      <h1>{title}</h1>


      {width < 760 ? (
        <FaMobileAlt />
      ) : width < 990 ? (
        <FaTabletAlt />
      ) : (
        <FaLaptop />
      )}
    </header>
  );
};

export default Header;
