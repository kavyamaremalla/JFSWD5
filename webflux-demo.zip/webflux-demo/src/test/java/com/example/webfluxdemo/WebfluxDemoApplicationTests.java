package com.example.webfluxdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
