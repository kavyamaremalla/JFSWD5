package com.example.webfluxdemo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.List;

public class FluxMonoGenarativeService {

    public static void main(String[] args) {
        FluxMonoGenarativeService service = new FluxMonoGenarativeService();
//        service.namesFlux().log(); //publisher
        service.namesFlux().subscribe(s -> System.out.println(s));
        service.nameMono().subscribe(System.out::println);

//        Tuple2<String, String> tuple = Tuple2.of("Hello","World");
//        tuple.getT1();
//        tuple.getT2();
        
    }

    public Flux<String> namesFlux() {
        return Flux.fromIterable(List.of("John", "Peter", "Harry", "Sd"))
                .map(String::toUpperCase)
                .filter(name -> name.length()>3)
                .log();
    }

    public Mono<String> nameMono() {
        return Mono.just("Zack").log();
    }

    
}
