package org.example;


import java.sql.*;

public class JDBCDemo {
    public static void main(String[] args) {
        {

            StringBuilder selectQuery = new StringBuilder();
            selectQuery.append("select * from persons ");
            selectQuery.append("where personId = 1;");

//            connectToSQLDB(selectQuery);

            StringBuilder updateQuery = new StringBuilder();
            updateQuery.append("update * from persons ");

//            connectToSQLDB(updateQuery);
        }
    }

    private static void connectToSQLDB(StringBuilder query) {
        try (Connection connection  = DriverManager.getConnection("jdbc:mysql://localhost/personsdb?user=root&password=Password!123");
             PreparedStatement preparedStatement = connection.prepareStatement(String.valueOf(query));

             ResultSet resultSet = preparedStatement.executeQuery()){


            while(resultSet.next()){
                System.out.println(resultSet.getInt(1));
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}