package org.example;

import com.mongodb.MongoException;
import com.mongodb.client.*;
import org.bson.Document;

public class MongoDBDemo {

    public static void main(String[] args) {

        try{
            findDocuments();
            findOneDocument();
        }catch (MongoException mongoException){
            System.out.println(mongoException.getMessage());
        }



    }

    private static void findOneDocument() {
        MongoCollection<Document> document = connectivityToMongoDB();

        FindIterable<Document> documents =  document.find();
        documents.forEach(System.out::println);
    }
    private static void findDocuments() {
        MongoCollection<Document> document = connectivityToMongoDB();
        FindIterable<Document> documents =  document.find();
        documents.forEach(System.out::println);
    }



    private static MongoCollection<Document> connectivityToMongoDB() {
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase database = mongoClient.getDatabase("schools");
        MongoCollection<Document> document = database.getCollection("contacts");
        return document;
    }
}
