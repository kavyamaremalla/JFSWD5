package models;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.context.annotation.Lazy;

import java.util.List;

@Entity
@Data
public class Persons {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int personId;

    private String firstName;

    private String lastName;

    private Boolean isMarried;

    @OneToMany(mappedBy = "persons")
    private List<Orders> orders;

}
