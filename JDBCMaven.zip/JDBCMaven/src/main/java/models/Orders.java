package models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;
import lombok.ToString;

@Entity
@Data
public class Orders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId ;

   @Column(name = "personId", updatable = false, insertable = false)
   private int personId ;// PK of some other table

   private int orderNumber;

   private String orderDetails;

   @ManyToOne
   @JoinColumn(name = "personId")
   private Persons persons;

    @Override
    public String toString() {
        return "Orders{" +
                "orderId=" + orderId +
                ", orderNumber=" + orderNumber +
                ", orderDetails='" + orderDetails + '\'' +
                '}';
    }
}
