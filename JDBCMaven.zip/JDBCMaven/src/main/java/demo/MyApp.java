package demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyApp {
    public static void main(String[] args) {

//        CricketCoach coach1 = new CricketCoach();
//        coach1.setWishService(new HappyWishService());
//
//        System.out.println(coach1.getDailyWorkOut());
//        System.out.println(coach1.getWish());

        //Singleton Object creation : only one object can be created at one time..

        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);

        CricketCoach coach1 =  context.getBean("myCricketCoach", CricketCoach.class);
        FootBallCoach coach2 =  context.getBean("myFootBallCoach", FootBallCoach.class);

//        System.out.println(coach1.getWish());
//        System.out.println(coach2.getWish());

        SwimCoach coach =  context.getBean("swimCoach", SwimCoach.class);

        System.out.println(coach.getWish());

        //prototype, singleton, this bean definition creation, if you have multiple beans

        context.close(); //define this to call destroy

        //third party classes/jars



    }

}