package demo;


public interface WishService {

    public String getwish();
}
