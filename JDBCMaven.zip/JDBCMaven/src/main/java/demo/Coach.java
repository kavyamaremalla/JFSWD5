package demo;

public interface Coach {

     String getDailyWorkOut();

     String getWish();

}
