package demo;

public class SwimCoach implements Coach{

    private WishService wishService;

    public SwimCoach(WishService wishService) {
        this.wishService = wishService;
    }

    @Override
    public String getDailyWorkOut() {
        return null;
    }

    @Override
    public String getWish() {
        return null;
    }
}
