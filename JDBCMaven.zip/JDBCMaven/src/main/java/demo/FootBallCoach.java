package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("myFootBallCoach")
public class FootBallCoach implements Coach{


    @Autowired
   private  WishService wishService;

//    public FootBallCoach(WishService wishService) {
//        this.wishService = wishService;
//    }

    public void setWishService(WishService wishService) {
        this.wishService = wishService;
    }

    public String getDailyWorkOut(){
        return "Football Kick Practice";
    }

    @Override
    public String getWish() {
        return wishService.getwish();
    }
}
