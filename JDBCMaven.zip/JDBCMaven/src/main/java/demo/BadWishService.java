package demo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

//@Component
public class BadWishService implements WishService{
    @Override
    public String getwish() {
        return "bad luck";
    }
}
