package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component("myCricketCoach") //check-style --> define validations..
public class CricketCoach implements Coach{


    @Autowired
    @Qualifier("badWishService")
    private WishService wishService;


//    public CricketCoach(WishService wishService) {
//        this.wishService = wishService;
//    }

    private String email;

    //<constructor>

    public String getEmail() {
        return email;
    }

    @Value("${email}")
    public void setEmail(String email) {
        this.email = email;
    }

    public String getDailyWorkOut(){
        return "Batting Practice";
    }

    @Override
    public String getWish() {
        return wishService.getwish();
    }


    @PostConstruct
    public void startUpMethod(){
        System.out.println("Started");
    }

    @PreDestroy
    public void destroyMethod(){
        System.out.println("Destroyed");
    }
}
