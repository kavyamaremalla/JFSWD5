let tree = { firstName: "harry" };

const car = { 
              type: "nano", 
              model: '2023version', 
              color: "white",
              company :{
                name : "Tata",
                cost : 1000000,
                firstHand : true
              },
              carNameType : function () {
                return this.company.name + " " + this.type;
              }
             };


console.log(car.carNameType());

let result = function addNumbers(a, b, c) {
    return a + b + c;
}

console.log(result(1,2,3))