// let file = "https://reqres.in/api/users/2";

async function getData() {
  try {
    const response = await fetch("https://reqres.in/api/userspage=5000000000/non_existsx");

    if(response.ok){
     throw new Error ("invalid URL");
    }

    const result = await response.json();
    console.log(result);
  } catch (error) {
    console.error("Error : ", error);
  }
}

// getData();

fetch('https://reqres.in/api/users?page=2')
  .then((res) => res.json())
  .then((res) => console.log(res));
