public class MergeArray {
    public static void main(String[] args) {

        int[] arr1 = {1, 2, 4}; //i

        int[] arr2 = {2, 3, 5, 6, 7, 8, 9}; //j

        int i = 0, j = 0, k = 0;

        int[] res = new int[arr1.length + arr2.length];

        //time -> O(n+m) -> O(n)
        //space -> O(n+m) -> O(n)

        while (i < arr1.length && j < arr2.length) {
            if (arr1[i] < arr2[j]) {
                res[k] = arr1[i];
                i++;
            } else {
                res[k] = arr2[j];
                j++;
            }
            k++;
        }

        while (i < arr1.length) {
            res[k] = arr1[i];
            i++;
            k++;
        }

        while (j < arr2.length) {
            res[k] = arr2[j];
            j++;
            k++;
        }


        for (int l = 0; l < res.length; l++) {
            System.out.print(res[l]);
        }


    }
}

