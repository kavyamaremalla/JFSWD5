public class Recursion {

    public static void main(String[] args) {
        add(5);
    }

    public static void add(int i){
        if(i==0){
            return;
        }
        System.out.println("DSA Intro Session: " + i);
        add(i -1);
    }
}
