public class LinearSearch {
    public static void main(String[] args) {
        int x =7;
        int[] arr = {1,2,3,4,5,6,7};
        int[] arr2 = arr; //space complexity

        for (int i = 0; i < arr.length; i++) {
                if(arr[i] == x){//O(1)
                    System.out.println("Found x " + x);
                }
        }

        for (int j = 0; j < arr.length; j++) {
            arr2[j] = 1; //space, O(2)
            System.out.println(j);
        }
    }
}
